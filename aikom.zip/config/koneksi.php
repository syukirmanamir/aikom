<?php

$host = 'localhost';
$nama = 'root';
$pass = 'root';
$db = 'aikom_pmb';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
if(!$koneksi){
  echo "tara takonek";
}
?>
