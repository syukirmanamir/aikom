<?php
//include('dbconnected.php');
include('../config/koneksi.php');

$id = $_GET['id'];
$nama = $_GET['nama'];
$jenis_kelamin = $_GET['jenis_kelamin'];
$alamat = $_GET['alamat'];
$no_tlpn = $_GET['no_tlpn'];
$agama = $_GET['agama'];
$asal_sekolah = $_GET['asal_sekolah'];
$jurusan = $_GET['jurusan'];



//query update
$query = mysqli_query($koneksi,"UPDATE pmb SET nama='$nama', jenis_kelamin='$jenis_kelamin', alamat='$alamat', no_tlpn='$no_tlpn', agama='$agama', asal_sekolah='$asal_sekolah', jurusan='$jurusan' WHERE id='$id'");

if ($query) {
 # credirect ke page index
 header("location:../data-mhs.php");
}
else{
 echo "ERROR, data gagal diupdate". mysql_error();
}

//mysql_close($host);
?>
