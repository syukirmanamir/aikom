<?php
//include('dbconnected.php');
include('../config/koneksi.php');

$id = $_GET['id_user'];
$nama = $_GET['nama'];
$email = $_GET['email'];
$pass = $_GET['password'];

//query update
$query = mysqli_query($koneksi,"UPDATE user SET nama='$nama' , email='$email', password='$pass' WHERE id_user='$id' ");

if ($query) {
 # credirect ke page index
 header("location:../profile.php");
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($Koneksi);
}

//mysql_close($host);
?>
