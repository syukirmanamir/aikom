<?php
//include('dbconnected.php');
include('../config/koneksi.php');

$nama = $_GET['nama'];
$jenis_kelamin = $_GET['jenis_kelamin'];
$alamat = $_GET['alamat'];
$no_tlpn = $_GET['no_tlpn'];
$agama = $_GET['agama'];
$asal_sekolah = $_GET['asal_sekolah'];
$jurusan = $_GET['jurusan'];



//query tambah
$query = mysqli_query($koneksi,"INSERT INTO `pmb` (`id`, `nama`, `jenis_kelamin`, `alamat`, `no_tlpn`, `agama`, `asal_sekolah`, `jurusan`) VALUES
(null, '$nama', '$jenis_kelamin', '$alamat', '$no_tlpn', '$agama', '$asal_sekolah', '$jurusan')");

if ($query) {
 # credirect ke page index
 header("location:../data-mhs.php");
}
else{
 echo "ERROR, data gagal ditambah". mysqli_error($koneksi);
}

//mysql_close($host);
?>
