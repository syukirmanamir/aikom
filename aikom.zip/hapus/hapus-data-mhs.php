<?php
//include('dbconnected.php');
include('../config/koneksi.php');

$id = $_GET['id'];

//query update
$query = mysqli_query($koneksi,"DELETE FROM `pmb` WHERE id = '$id'");

if ($query) {
 # credirect ke page index
 header("location:../data-mhs.php");
}
else{
 echo "ERROR, data gagal dihapus". mysqli_error($koneksi);
}

//mysql_close($host);
?>
