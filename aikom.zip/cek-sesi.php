	<!-- cek apakah sudah login -->
	<?php
    session_start();
    if (!isset($_SESSION['nama'])){
        header("Location: login.php");
    }
?>
