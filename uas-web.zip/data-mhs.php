<?php require './cek-sesi.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>DATA MHS</title>

  <!-- Custom fonts for this template -->
  <link href="./config/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="./config/css/aikom.css" rel="stylesheet">
  <link href="./config/css/style.css" rel="stylesheet">
  <link href="./config/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">


  <!-- Custom styles for this page -->


</head>

<body id="page-top">
<?php require './config/koneksi.php'; ?>
<?php require './config/sidebar-aikom.php'; ?>
      <!-- Main Content -->
      <div id="content">

<?php require './config/navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">




          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <button type="button" class="btn btn-warning float-right" style="margin:5px" data-toggle="modal" data-target="#myModalTambah"><i class="fa fa-plus"> DATA</i></button><br>
              <h6 class="m-0 font-weight-bold text-primary">DATA MHS</h6>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>No</th>
                      <th>NAMA</th>
                      <th>JENIS KELAMIN</th>
                      <th>ALAMAT</th>
                      <th>NO HP</th>
                      <th>AGAMA</th>
                      <th>ASAL SEKOLAH</th>
                      <th>JURUSAN</th>
                      <th>Aksi</th>
                    </tr>
                  </thead>

                  <?php
$query = mysqli_query($koneksi,"SELECT * FROM pmb");
$no = 1;
while ($data = mysqli_fetch_assoc($query))
{
?>
                    <tr>
                      <td><?= $no++; ?></td>
                      <td><?=$data['nama']?></td>
                      <td><?=$data['jenis_kelamin']?></td>
                      <td><?=$data['alamat']?></td>
                      <td><?=$data['no_tlpn']?></td>
                      <td><?=$data['agama']?></td>
                      <td><?=$data['asal_sekolah']?></td>
                      <td><?=$data['jurusan']?></td>
					  <td>
                    <!-- Button untuk modal -->
<a href="#" type="button" class=" fa fa-edit btn btn-success" data-toggle="modal" data-target="#myModal<?php echo $data['id']; ?>"></a>
</td>
</tr>
<!-- Modal Edit Mahasiswa-->
<div class="modal fade" id="myModal<?php echo $data['id']; ?>" role="dialog">
<div class="modal-dialog">

<!-- Modal content-->
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">Ubah Data</h4>
<button type="button" class="close" data-dismiss="modal">&times;</button>
</div>
<div class="modal-body">
<form role="form" action="./edit/edit-data-mhs.php" method="get">

<?php
$id = $data['id'];
$query_edit = mysqli_query($koneksi,"SELECT * FROM pmb WHERE id='$id'");
//$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_array($query_edit)) {
?>


<input type="hidden" name="id" value="<?php echo $row['id']; ?>">

<div class="form-group">
<label>NAMA</label>
<input type="text" name="nama" class="form-control" value="<?php echo $row['nama']; ?>">
</div>

<div class="form-group">
<label>JENIS KELAMIN</label>
<select class="form-control" name="jenis_kelamin" type="text">
    <option>Pilih</option>
    <option value="LAKI-LAKI">LAKI-LAKI</option>
    <option value="PEREMPUAN">PEREMPUAN</option>
</select>
</div>

<div class="form-group">
<label>ALAMAT</label>
<input type="text" name="alamat" class="form-control" value="<?php echo $row['alamat']; ?>">
</div>

<div class="form-group">
<label>NO HP</label>
<input type="text" name="no_tlpn" class="form-control" value="<?php echo $row['no_tlpn']; ?>">
</div>

<div class="form-group">
<label>AGAMA</label>
<input type="text" name="agama" class="form-control" value="<?php echo $row['agama']; ?>">
</div>

<div class="form-group">
<label>ASAL SEKOLAH</label>
<input type="text" name="asal_sekolah" class="form-control" value="<?php echo $row['asal_sekolah']; ?>">
</div>

<div class="form-group">
<label>JURUSAN</label>
<select class="form-control" name="jurusan" type="text">
    <option>Pilih</option>
    <option value="MI">MI</option>
    <option value="TK">TK</option>
</select>
</div>

<div class="modal-footer">
<button type="submit" class="btn btn-primary">Ubah</button>
<a href="./hapus/hapus-data-mhs.php?id=<?=$row['id'];?>" Onclick="confirm('Anda Yakin Ingin Menghapus?')" class="btn btn-danger">Hapus</a>
<button type="button" class="btn btn-warning" data-dismiss="modal">Keluar</button>
</div>
<?php
}
//mysql_close($host);
?>

</form>
</div>
</div>

</div>
</div>



 <!-- Modal -->
  <div id="myModalTambah" class="modal fade" role="dialog">
    <div class="modal-dialog">

      <!-- konten modal-->
      <div class="modal-content">
        <!-- heading modal -->
        <div class="modal-header">
          <h4 class="modal-title">Tambah Data</h4>
		    <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <!-- body modal -->
		<form action="./tambah/tambah-data-mhs.php" method="get">
        <div class="modal-body">
		NAMA :
         <input type="text" class="form-control" name="nama">
    JENIS KELAMIN :
        <select class="form-control" name="j_kelamin" type="text">
            <option>Pilih</option>
            <option value="LAKI-LAKI">LAKI-LAKI</option>
            <option value="PEREMPUAN">PEREMPUAN</option>
        </select>
    ALAMAT :
         <input type="text" class="form-control" name="alamat">
    NO HP :
         <input type="text" class="form-control" name="no_tlpn">
    AGAMA :
         <input type="text" class="form-control" name="agama">
    ASAL SEKOLAH :
         <input type="text" class="form-control" name="asal_sekolah">
    JURUSAN :
         <select class="form-control" name="jurusan" type="text">
            <option>Pilih</option>
            <option value="MI">MI</option>
            <option value="TK">TK</option>
          </select>
        <!-- footer modal -->
        <div class="modal-footer">
		<button type="submit" class="btn btn-warning" >Tambah</button>
		</form>
          <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
        </div>
      </div>

    </div>
  </div>


<?php
}
?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>


        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

<?php require './config/footer.php'?>

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
<?php require 'logout-modal.php';?>

  <!-- Bootstrap core JavaScript-->
  <script src="./config/vendor/jquery/jquery.min.js"></script>
  <script src="./config/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="./config/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="./config/js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="./config/vendor/datatables/jquery.dataTables.min.js"></script>
  <script src="./config/vendor/datatables/dataTables.bootstrap4.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="./config/js/demo/datatables-demo.js"></script>

</body>

</html>
