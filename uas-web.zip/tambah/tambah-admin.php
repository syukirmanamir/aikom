<?php
//include('dbconnected.php');
include('../config/koneksi.php');

$nama = $_GET['nama'];
$email = $_GET['email'];
$pass = $_GET['password'];


//query update
$query = mysqli_query($koneksi,"INSERT INTO `user` (`id_user`, `nama`, `email`, `password`) VALUES (null, '$nama', '$email', '$pass')");

if ($query) {
 # credirect ke page index
 header("location:../profile.php");
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>
