<?php

$host = 'localhost';
$nama = 'id20159561_auswebhmjmi';
$pass = '#Tugas_susah_skali_2023';
$db = 'id20159561_aikom_pmb';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
if(!$koneksi){
  echo "tara takonek";
}
?>
