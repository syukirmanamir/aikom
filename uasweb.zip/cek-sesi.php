	<!-- cek apakah sudah login -->
<?php
    session_start();
    require './config/koneksi.php';
    if (!isset($_SESSION['nama'])){
        header("Location: ./login.php");
    }
?>
