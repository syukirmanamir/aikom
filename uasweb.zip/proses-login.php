<?php
// mengaktifkan session php
session_start();

// menghubungkan dengan koneksi
include './config/koneksi.php';
 
// menangkap data yang dikirim dari form
$email =mysqli_real_escape_string($koneksi,$_POST['email']);
$pass =mysqli_real_escape_string($koneksi, $_POST['password']);

// menyeleksi data admin dengan username dan password yang sesuai
$data = mysqli_query($koneksi,"select * from user where email='$email' and password='$pass'");

// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);

if($cek > 0){
$sesi = mysqli_query($koneksi,"select * from user where email='$email' and password='$pass'");
$sesi = mysqli_fetch_assoc($sesi);
	$_SESSION['id_user'] = $sesi['id_user'];
	$_SESSION['nama'] = $sesi['nama'];
	$_SESSION['status'] = "login";
	header("location:index.php");
}else{
	header("location:login.php?pesan=gagal");
}
?>
